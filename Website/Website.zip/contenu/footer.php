<footer class="footer">
    <div class="row">
        <div class="col-sm-4">Le handicap psychique.</div>
        <div class="col-sm-6"></div>
        <div class="col-sm-2"><a href="ressources/Notice.pdf" target="_blank" class="link pull-right"> > Voir la notice du site < </a></div>
    </div>
</footer>