<?php
	$servername = "localhost";
	$username = "handicap-psychiq";
	$password = "g94lrXv873v2";
	$dbName = "handicap-psychiq";

	$conn = new mysqli($servername, $username, $password, $dbName);

	if ($conn->connect_error) 
	{
    	die("Connection failed: ".$conn->connect_error);
    }
?>